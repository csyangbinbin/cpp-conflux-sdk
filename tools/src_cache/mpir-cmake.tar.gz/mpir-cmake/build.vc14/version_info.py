﻿
# returns:
#   solution file version
#   visual studio version
#   microsoft compiler version
#   microsoft compiler version (long)
#   vcx project tools version
vs_info = { 'solution':'12',
            'visual studio':'14',
            'msvc':'14',
            'msvc_long':'14.0.24720.0',
            'vcx_tool':'14.0',
            'platform_toolset':'140'
          }
