#define TUNE_PROGRAM_BUILD 1
#include "..\..\..\fft\mul_mfa_trunc_sqrt2.c"
