#define TUNE_PROGRAM_BUILD 1
#include "..\..\..\mpn\generic\toom8_sqr_n.c"
