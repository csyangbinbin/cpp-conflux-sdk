#define TUNE_PROGRAM_BUILD 1
#include "..\..\..\mpn\generic\toom4_mul_n.c"
