#define TUNE_PROGRAM_BUILD 1
#include "..\..\..\mpn\generic\sb_div_qr.c"
