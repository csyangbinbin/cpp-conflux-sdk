#define TUNE_PROGRAM_BUILD 1
#include "..\..\..\fft\fft_mfa_trunc_sqrt2_inner.c"
