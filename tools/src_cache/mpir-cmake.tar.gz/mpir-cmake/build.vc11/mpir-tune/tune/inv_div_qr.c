#define TUNE_PROGRAM_BUILD 1
#include "..\..\..\mpn\generic\inv_div_qr.c"
